﻿namespace Optima2.DataSets {
    
    
    public partial class Quotation {
    }
}
