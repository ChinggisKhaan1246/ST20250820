namespace Optima2.Print
{
    partial class Quotation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Quotation));
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.dsQuotation = new Optima2.DataSets.Quotation();
            this.ReportHeader = new DevExpress.XtraReports.UI.ReportHeaderBand();
            this.xrLabel2 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrlblJobDescription = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport1 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.AmendmentNumber = new DevExpress.XtraReports.UI.DetailBand();
            this.xrlblAmendmentNumber = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport3 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Print_Job = new DevExpress.XtraReports.UI.DetailBand();
            this.xrlblNoOfParts = new DevExpress.XtraReports.UI.XRLabel();
            this.xrlblNoParts = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport6 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Printjob_PrintSpec = new DevExpress.XtraReports.UI.DetailBand();
            this.xrlblPrintSpecDesc = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel9 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel4 = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail_PrintJob = new DevExpress.XtraReports.UI.DetailBand();
            this.xrLabel3 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrlblOverallSize = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport5 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Additional_Info = new DevExpress.XtraReports.UI.DetailBand();
            this.xrRTFAdditionalInformation = new DevExpress.XtraReports.UI.XRRichText();
            this.xrLabel8 = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport8 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.RepeatInformation = new DevExpress.XtraReports.UI.DetailBand();
            this.xrLabel11 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel10 = new DevExpress.XtraReports.UI.XRLabel();
            this.Selling_Prices = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail1 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTable1 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow1 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell1 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell2 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell3 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell4 = new DevExpress.XtraReports.UI.XRTableCell();
            this.GroupHeader3 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.xrLabel13 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel6 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel15 = new DevExpress.XtraReports.UI.XRLabel();
            this.GroupHeader2 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.Del_Sched = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail3 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrlblDelSchedInfo = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel17 = new DevExpress.XtraReports.UI.XRLabel();
            this.Deliver_To = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail4 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrlblDeliveryTo = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel18 = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport9 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail5 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrlblDeliveryDate = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel19 = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport10 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Terms = new DevExpress.XtraReports.UI.DetailBand();
            this.xrlblTerms = new DevExpress.XtraReports.UI.XRRichText();
            this.xrLabel16 = new DevExpress.XtraReports.UI.XRLabel();
            this.topMarginBand1 = new DevExpress.XtraReports.UI.TopMarginBand();
            this.bottomMarginBand1 = new DevExpress.XtraReports.UI.BottomMarginBand();
            this.jOBFILETableAdapter = new Optima2.DataSets.QuotationTableAdapters.JOBFILETableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dsQuotation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrRTFAdditionalInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrlblTerms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.HeightF = 0F;
            this.Detail.Name = "Detail";
            this.Detail.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // dsQuotation
            // 
            this.dsQuotation.DataSetName = "Quotation";
            this.dsQuotation.EnforceConstraints = false;
            this.dsQuotation.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ReportHeader
            // 
            this.ReportHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel2,
            this.xrlblJobDescription});
            this.ReportHeader.HeightF = 25F;
            this.ReportHeader.Name = "ReportHeader";
            this.ReportHeader.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.ReportHeader.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel2
            // 
            this.xrLabel2.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel2.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel2.Name = "xrLabel2";
            this.xrLabel2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel2.SizeF = new System.Drawing.SizeF(100F, 25F);
            this.xrLabel2.StylePriority.UseFont = false;
            this.xrLabel2.Text = "Description";
            this.xrLabel2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblJobDescription
            // 
            this.xrlblJobDescription.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "JOBFILE.JOB_DESC")});
            this.xrlblJobDescription.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrlblJobDescription.LocationFloat = new DevExpress.Utils.PointFloat(119.0832F, 0F);
            this.xrlblJobDescription.Multiline = true;
            this.xrlblJobDescription.Name = "xrlblJobDescription";
            this.xrlblJobDescription.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblJobDescription.SizeF = new System.Drawing.SizeF(611.9167F, 25F);
            this.xrlblJobDescription.Text = "xrlblJobDescription";
            this.xrlblJobDescription.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // DetailReport1
            // 
            this.DetailReport1.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.AmendmentNumber});
            this.DetailReport1.DataSource = this.dsQuotation;
            this.DetailReport1.Level = 8;
            this.DetailReport1.Name = "DetailReport1";
            this.DetailReport1.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.DetailReport1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // AmendmentNumber
            // 
            this.AmendmentNumber.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrlblAmendmentNumber});
            this.AmendmentNumber.HeightF = 25F;
            this.AmendmentNumber.Name = "AmendmentNumber";
            this.AmendmentNumber.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.AmendmentNumber.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblAmendmentNumber
            // 
            this.xrlblAmendmentNumber.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrlblAmendmentNumber.LocationFloat = new DevExpress.Utils.PointFloat(275F, 0F);
            this.xrlblAmendmentNumber.Multiline = true;
            this.xrlblAmendmentNumber.Name = "xrlblAmendmentNumber";
            this.xrlblAmendmentNumber.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblAmendmentNumber.Scripts.OnBeforePrint = "xrlblAmendmentNumber_BeforePrint";
            this.xrlblAmendmentNumber.SizeF = new System.Drawing.SizeF(200F, 25F);
            this.xrlblAmendmentNumber.StylePriority.UseFont = false;
            this.xrlblAmendmentNumber.Text = "xrlblAmendmentNumber";
            this.xrlblAmendmentNumber.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // DetailReport3
            // 
            this.DetailReport3.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Print_Job,
            this.DetailReport6,
            this.DetailReport});
            this.DetailReport3.DataSource = this.dsQuotation;
            this.DetailReport3.Level = 7;
            this.DetailReport3.Name = "DetailReport3";
            this.DetailReport3.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.DetailReport3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Print_Job
            // 
            this.Print_Job.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrlblNoOfParts,
            this.xrlblNoParts});
            this.Print_Job.HeightF = 25F;
            this.Print_Job.Name = "Print_Job";
            this.Print_Job.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Print_Job.Scripts.OnBeforePrint = "Print_Job_BeforePrint";
            this.Print_Job.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblNoOfParts
            // 
            this.xrlblNoOfParts.LocationFloat = new DevExpress.Utils.PointFloat(119.0832F, 0F);
            this.xrlblNoOfParts.Name = "xrlblNoOfParts";
            this.xrlblNoOfParts.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblNoOfParts.Scripts.OnBeforePrint = "xrlblNoOfParts_BeforePrint";
            this.xrlblNoOfParts.SizeF = new System.Drawing.SizeF(267F, 25F);
            this.xrlblNoOfParts.Text = "xrlblNoOfParts";
            this.xrlblNoOfParts.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblNoParts
            // 
            this.xrlblNoParts.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrlblNoParts.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrlblNoParts.Name = "xrlblNoParts";
            this.xrlblNoParts.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblNoParts.Scripts.OnBeforePrint = "xrlblNoParts_BeforePrint";
            this.xrlblNoParts.SizeF = new System.Drawing.SizeF(100F, 25F);
            this.xrlblNoParts.StylePriority.UseFont = false;
            this.xrlblNoParts.Text = "No. of Parts";
            this.xrlblNoParts.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // DetailReport6
            // 
            this.DetailReport6.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Printjob_PrintSpec});
            this.DetailReport6.DataMember = "JOBFILE.JOBFILE_PRINTSPC";
            this.DetailReport6.DataSource = this.dsQuotation;
            this.DetailReport6.Level = 1;
            this.DetailReport6.Name = "DetailReport6";
            this.DetailReport6.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.DetailReport6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Printjob_PrintSpec
            // 
            this.Printjob_PrintSpec.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrlblPrintSpecDesc,
            this.xrLabel9,
            this.xrLabel4});
            this.Printjob_PrintSpec.HeightF = 54.50001F;
            this.Printjob_PrintSpec.Name = "Printjob_PrintSpec";
            this.Printjob_PrintSpec.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Printjob_PrintSpec.Scripts.OnBeforePrint = "Printjob_PrintSpec_BeforePrint";
            this.Printjob_PrintSpec.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblPrintSpecDesc
            // 
            this.xrlblPrintSpecDesc.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrlblPrintSpecDesc.LocationFloat = new DevExpress.Utils.PointFloat(119.0832F, 17.00001F);
            this.xrlblPrintSpecDesc.Multiline = true;
            this.xrlblPrintSpecDesc.Name = "xrlblPrintSpecDesc";
            this.xrlblPrintSpecDesc.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblPrintSpecDesc.Scripts.OnBeforePrint = "xrlblPrintSpecDesc_BeforePrint";
            this.xrlblPrintSpecDesc.SizeF = new System.Drawing.SizeF(611.9169F, 25F);
            this.xrlblPrintSpecDesc.Text = "xrlblPrintSpecDesc";
            this.xrlblPrintSpecDesc.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel9
            // 
            this.xrLabel9.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "JOBFILE.JOBFILE_PRINTSPC.PART_DESC")});
            this.xrLabel9.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))));
            this.xrLabel9.LocationFloat = new DevExpress.Utils.PointFloat(119.0832F, 0F);
            this.xrLabel9.Name = "xrLabel9";
            this.xrLabel9.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel9.SizeF = new System.Drawing.SizeF(267F, 17F);
            this.xrLabel9.StylePriority.UseFont = false;
            this.xrLabel9.Text = "xrLabel9";
            this.xrLabel9.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel4
            // 
            this.xrLabel4.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel4.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel4.Name = "xrLabel4";
            this.xrLabel4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel4.Scripts.OnBeforePrint = "xrLabel4_BeforePrint";
            this.xrLabel4.SizeF = new System.Drawing.SizeF(100F, 17F);
            this.xrLabel4.StylePriority.UseFont = false;
            this.xrLabel4.Text = "Printing";
            this.xrLabel4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // DetailReport
            // 
            this.DetailReport.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail_PrintJob});
            this.DetailReport.Level = 0;
            this.DetailReport.Name = "DetailReport";
            // 
            // Detail_PrintJob
            // 
            this.Detail_PrintJob.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel3,
            this.xrlblOverallSize});
            this.Detail_PrintJob.HeightF = 25F;
            this.Detail_PrintJob.Name = "Detail_PrintJob";
            this.Detail_PrintJob.Scripts.OnBeforePrint = "Detail_PrintJob_BeforePrint";
            // 
            // xrLabel3
            // 
            this.xrLabel3.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel3.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel3.Name = "xrLabel3";
            this.xrLabel3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel3.SizeF = new System.Drawing.SizeF(100F, 25F);
            this.xrLabel3.StylePriority.UseFont = false;
            this.xrLabel3.Text = "Overall Size";
            this.xrLabel3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblOverallSize
            // 
            this.xrlblOverallSize.LocationFloat = new DevExpress.Utils.PointFloat(119.0832F, 0F);
            this.xrlblOverallSize.Name = "xrlblOverallSize";
            this.xrlblOverallSize.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblOverallSize.Scripts.OnBeforePrint = "xrlblOverallSize_BeforePrint";
            this.xrlblOverallSize.SizeF = new System.Drawing.SizeF(391F, 25F);
            this.xrlblOverallSize.Text = "xrlblOverallSize";
            this.xrlblOverallSize.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // DetailReport5
            // 
            this.DetailReport5.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Additional_Info});
            this.DetailReport5.DataSource = this.dsQuotation;
            this.DetailReport5.Level = 6;
            this.DetailReport5.Name = "DetailReport5";
            this.DetailReport5.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.DetailReport5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Additional_Info
            // 
            this.Additional_Info.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrRTFAdditionalInformation,
            this.xrLabel8});
            this.Additional_Info.HeightF = 25F;
            this.Additional_Info.Name = "Additional_Info";
            this.Additional_Info.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Additional_Info.Scripts.OnBeforePrint = "Additional_Info_BeforePrint";
            this.Additional_Info.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrRTFAdditionalInformation
            // 
            this.xrRTFAdditionalInformation.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrRTFAdditionalInformation.LocationFloat = new DevExpress.Utils.PointFloat(119.0833F, 0F);
            this.xrRTFAdditionalInformation.Name = "xrRTFAdditionalInformation";
            this.xrRTFAdditionalInformation.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrRTFAdditionalInformation.SerializableRtfString = resources.GetString("xrRTFAdditionalInformation.SerializableRtfString");
            this.xrRTFAdditionalInformation.SizeF = new System.Drawing.SizeF(611.9167F, 25F);
            this.xrRTFAdditionalInformation.StylePriority.UsePadding = false;
            this.xrRTFAdditionalInformation.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel8
            // 
            this.xrLabel8.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.xrLabel8.KeepTogether = true;
            this.xrLabel8.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel8.Name = "xrLabel8";
            this.xrLabel8.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel8.Scripts.OnBeforePrint = "xrLabel8_BeforePrint";
            this.xrLabel8.SizeF = new System.Drawing.SizeF(100F, 25F);
            this.xrLabel8.StylePriority.UseFont = false;
            this.xrLabel8.Text = "Additional Information";
            this.xrLabel8.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // DetailReport8
            // 
            this.DetailReport8.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.RepeatInformation});
            this.DetailReport8.DataSource = this.dsQuotation;
            this.DetailReport8.Level = 5;
            this.DetailReport8.Name = "DetailReport8";
            this.DetailReport8.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.DetailReport8.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // RepeatInformation
            // 
            this.RepeatInformation.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel11,
            this.xrLabel10});
            this.RepeatInformation.HeightF = 25F;
            this.RepeatInformation.Name = "RepeatInformation";
            this.RepeatInformation.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.RepeatInformation.Scripts.OnBeforePrint = "RepeatInformation_BeforePrint";
            this.RepeatInformation.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel11
            // 
            this.xrLabel11.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel11.LocationFloat = new DevExpress.Utils.PointFloat(119.0833F, 0F);
            this.xrLabel11.Multiline = true;
            this.xrLabel11.Name = "xrLabel11";
            this.xrLabel11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel11.Scripts.OnBeforePrint = "xrLabel11_BeforePrint";
            this.xrLabel11.SizeF = new System.Drawing.SizeF(611.9167F, 25F);
            this.xrLabel11.Text = "xrRepeatJobInfo";
            this.xrLabel11.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel10
            // 
            this.xrLabel10.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel10.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel10.Name = "xrLabel10";
            this.xrLabel10.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel10.SizeF = new System.Drawing.SizeF(100F, 25F);
            this.xrLabel10.StylePriority.UseFont = false;
            this.xrLabel10.Text = "Repeat Job";
            this.xrLabel10.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Selling_Prices
            // 
            this.Selling_Prices.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail1,
            this.GroupHeader3});
            this.Selling_Prices.DataMember = "JOBFILE.JOBFILE_PRICES";
            this.Selling_Prices.DataSource = this.dsQuotation;
            this.Selling_Prices.Level = 4;
            this.Selling_Prices.Name = "Selling_Prices";
            this.Selling_Prices.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Selling_Prices.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Detail1
            // 
            this.Detail1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable1});
            this.Detail1.HeightF = 17F;
            this.Detail1.Name = "Detail1";
            this.Detail1.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrTable1
            // 
            this.xrTable1.LocationFloat = new DevExpress.Utils.PointFloat(119.0832F, 0F);
            this.xrTable1.Name = "xrTable1";
            this.xrTable1.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow1});
            this.xrTable1.SizeF = new System.Drawing.SizeF(611.9167F, 17F);
            // 
            // xrTableRow1
            // 
            this.xrTableRow1.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell1,
            this.xrTableCell2,
            this.xrTableCell3,
            this.xrTableCell4});
            this.xrTableRow1.Name = "xrTableRow1";
            this.xrTableRow1.Weight = 0.408D;
            // 
            // xrTableCell1
            // 
            this.xrTableCell1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "JOBFILE.JOBFILE_PRICES.QUANTITY")});
            this.xrTableCell1.Name = "xrTableCell1";
            this.xrTableCell1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrTableCell1.StylePriority.UsePadding = false;
            this.xrTableCell1.Text = "xrTableCell1";
            this.xrTableCell1.Weight = 0.564179700262279D;
            // 
            // xrTableCell2
            // 
            this.xrTableCell2.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "JOBFILE.JOBFILE_PRICES.PRODUCT")});
            this.xrTableCell2.Name = "xrTableCell2";
            this.xrTableCell2.Text = "xrTableCell2";
            this.xrTableCell2.Weight = 0.7989155291174499D;
            // 
            // xrTableCell3
            // 
            this.xrTableCell3.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "JOBFILE.JOBFILE_PRICES.PRICE")});
            this.xrTableCell3.Name = "xrTableCell3";
            this.xrTableCell3.Text = "xrTableCell3";
            this.xrTableCell3.Weight = 0.76811623663960282D;
            // 
            // xrTableCell4
            // 
            this.xrTableCell4.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "JOBFILE.JOBFILE_PRICES.NOTES")});
            this.xrTableCell4.Name = "xrTableCell4";
            this.xrTableCell4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 0, 0, 0, 100F);
            this.xrTableCell4.StylePriority.UsePadding = false;
            this.xrTableCell4.Text = "xrTableCell4";
            this.xrTableCell4.Weight = 1.669489308664041D;
            // 
            // GroupHeader3
            // 
            this.GroupHeader3.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel13,
            this.xrLabel6,
            this.xrLabel15});
            this.GroupHeader3.HeightF = 17F;
            this.GroupHeader3.KeepTogether = true;
            this.GroupHeader3.Name = "GroupHeader3";
            // 
            // xrLabel13
            // 
            this.xrLabel13.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel13.LocationFloat = new DevExpress.Utils.PointFloat(119.0833F, 0F);
            this.xrLabel13.Name = "xrLabel13";
            this.xrLabel13.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel13.SizeF = new System.Drawing.SizeF(90.83F, 17F);
            this.xrLabel13.StylePriority.UseFont = false;
            this.xrLabel13.Text = "Quantity";
            this.xrLabel13.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel6
            // 
            this.xrLabel6.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel6.LocationFloat = new DevExpress.Utils.PointFloat(338.5417F, 0F);
            this.xrLabel6.Name = "xrLabel6";
            this.xrLabel6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel6.SizeF = new System.Drawing.SizeF(123.67F, 17F);
            this.xrLabel6.StylePriority.UseFont = false;
            this.xrLabel6.Text = "Price";
            this.xrLabel6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel15
            // 
            this.xrLabel15.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel15.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel15.Name = "xrLabel15";
            this.xrLabel15.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel15.SizeF = new System.Drawing.SizeF(100F, 17F);
            this.xrLabel15.StylePriority.UseFont = false;
            this.xrLabel15.Text = "Costs";
            // 
            // GroupHeader2
            // 
            this.GroupHeader2.HeightF = 47F;
            this.GroupHeader2.Level = 1;
            this.GroupHeader2.Name = "GroupHeader2";
            // 
            // Del_Sched
            // 
            this.Del_Sched.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail3});
            this.Del_Sched.DataMember = "JOBFILE.JOBFILE_DELSCHED";
            this.Del_Sched.DataSource = this.dsQuotation;
            this.Del_Sched.Level = 3;
            this.Del_Sched.Name = "Del_Sched";
            this.Del_Sched.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Del_Sched.Scripts.OnBeforePrint = "Del_Sched_BeforePrint";
            this.Del_Sched.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Detail3
            // 
            this.Detail3.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrlblDelSchedInfo,
            this.xrLabel17});
            this.Detail3.HeightF = 33F;
            this.Detail3.Name = "Detail3";
            this.Detail3.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblDelSchedInfo
            // 
            this.xrlblDelSchedInfo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrlblDelSchedInfo.LocationFloat = new DevExpress.Utils.PointFloat(119.0833F, 7.999992F);
            this.xrlblDelSchedInfo.Multiline = true;
            this.xrlblDelSchedInfo.Name = "xrlblDelSchedInfo";
            this.xrlblDelSchedInfo.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblDelSchedInfo.Scripts.OnBeforePrint = "xrlblDelSchedInfo_BeforePrint";
            this.xrlblDelSchedInfo.SizeF = new System.Drawing.SizeF(611.9167F, 25F);
            this.xrlblDelSchedInfo.Text = "xrlblDelSchedInfo";
            this.xrlblDelSchedInfo.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel17
            // 
            this.xrLabel17.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel17.LocationFloat = new DevExpress.Utils.PointFloat(0F, 8F);
            this.xrLabel17.Name = "xrLabel17";
            this.xrLabel17.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel17.Scripts.OnBeforePrint = "xrLabel17_BeforePrint";
            this.xrLabel17.SizeF = new System.Drawing.SizeF(100F, 25F);
            this.xrLabel17.StylePriority.UseFont = false;
            this.xrLabel17.Text = "Deliver To";
            this.xrLabel17.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Deliver_To
            // 
            this.Deliver_To.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail4});
            this.Deliver_To.DataSource = this.dsQuotation;
            this.Deliver_To.Level = 2;
            this.Deliver_To.Name = "Deliver_To";
            this.Deliver_To.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Deliver_To.Scripts.OnBeforePrint = "Deliver_To_BeforePrint";
            this.Deliver_To.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Detail4
            // 
            this.Detail4.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrlblDeliveryTo,
            this.xrLabel18});
            this.Detail4.HeightF = 33F;
            this.Detail4.Name = "Detail4";
            this.Detail4.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblDeliveryTo
            // 
            this.xrlblDeliveryTo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrlblDeliveryTo.LocationFloat = new DevExpress.Utils.PointFloat(119.0833F, 7.999992F);
            this.xrlblDeliveryTo.Multiline = true;
            this.xrlblDeliveryTo.Name = "xrlblDeliveryTo";
            this.xrlblDeliveryTo.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblDeliveryTo.Scripts.OnBeforePrint = "xrlblDeliveryTo_BeforePrint";
            this.xrlblDeliveryTo.SizeF = new System.Drawing.SizeF(611.9167F, 25F);
            this.xrlblDeliveryTo.Text = "xrlblDeliveryTo";
            this.xrlblDeliveryTo.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel18
            // 
            this.xrLabel18.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel18.LocationFloat = new DevExpress.Utils.PointFloat(0F, 8F);
            this.xrLabel18.Name = "xrLabel18";
            this.xrLabel18.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel18.SizeF = new System.Drawing.SizeF(100F, 25F);
            this.xrLabel18.StylePriority.UseFont = false;
            this.xrLabel18.Text = "Delivery To";
            this.xrLabel18.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // DetailReport9
            // 
            this.DetailReport9.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail5});
            this.DetailReport9.DataSource = this.dsQuotation;
            this.DetailReport9.Level = 1;
            this.DetailReport9.Name = "DetailReport9";
            this.DetailReport9.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.DetailReport9.Scripts.OnBeforePrint = "DetailReport9_BeforePrint";
            this.DetailReport9.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Detail5
            // 
            this.Detail5.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrlblDeliveryDate,
            this.xrLabel19});
            this.Detail5.HeightF = 25F;
            this.Detail5.Name = "Detail5";
            this.Detail5.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblDeliveryDate
            // 
            this.xrlblDeliveryDate.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrlblDeliveryDate.LocationFloat = new DevExpress.Utils.PointFloat(119.0833F, 0F);
            this.xrlblDeliveryDate.Multiline = true;
            this.xrlblDeliveryDate.Name = "xrlblDeliveryDate";
            this.xrlblDeliveryDate.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblDeliveryDate.Scripts.OnBeforePrint = "xrlblDeliveryDate_BeforePrint";
            this.xrlblDeliveryDate.SizeF = new System.Drawing.SizeF(611.9167F, 25F);
            this.xrlblDeliveryDate.Text = "xrlblDeliveryDate";
            this.xrlblDeliveryDate.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrLabel19
            // 
            this.xrLabel19.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel19.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel19.Name = "xrLabel19";
            this.xrLabel19.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel19.SizeF = new System.Drawing.SizeF(100F, 25F);
            this.xrLabel19.StylePriority.UseFont = false;
            this.xrLabel19.Text = "Delivery Date";
            this.xrLabel19.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // DetailReport10
            // 
            this.DetailReport10.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Terms});
            this.DetailReport10.DataSource = this.dsQuotation;
            this.DetailReport10.Level = 0;
            this.DetailReport10.Name = "DetailReport10";
            this.DetailReport10.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.DetailReport10.Scripts.OnBeforePrint = "DetailReport10_BeforePrint";
            this.DetailReport10.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // Terms
            // 
            this.Terms.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrlblTerms,
            this.xrLabel16});
            this.Terms.HeightF = 25F;
            this.Terms.KeepTogether = true;
            this.Terms.Name = "Terms";
            this.Terms.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Terms.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrlblTerms
            // 
            this.xrlblTerms.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrlblTerms.KeepTogether = true;
            this.xrlblTerms.LocationFloat = new DevExpress.Utils.PointFloat(119.0832F, 0F);
            this.xrlblTerms.Name = "xrlblTerms";
            this.xrlblTerms.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrlblTerms.SerializableRtfString = resources.GetString("xrlblTerms.SerializableRtfString");
            this.xrlblTerms.SizeF = new System.Drawing.SizeF(611.9168F, 22.99995F);
            this.xrlblTerms.StylePriority.UseFont = false;
            this.xrlblTerms.StylePriority.UsePadding = false;
            // 
            // xrLabel16
            // 
            this.xrLabel16.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel16.KeepTogether = true;
            this.xrLabel16.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel16.Name = "xrLabel16";
            this.xrLabel16.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel16.SizeF = new System.Drawing.SizeF(99.99999F, 25F);
            this.xrLabel16.StylePriority.UseFont = false;
            this.xrLabel16.Text = "Terms";
            this.xrLabel16.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // topMarginBand1
            // 
            this.topMarginBand1.HeightF = 22F;
            this.topMarginBand1.Name = "topMarginBand1";
            // 
            // bottomMarginBand1
            // 
            this.bottomMarginBand1.HeightF = 12F;
            this.bottomMarginBand1.Name = "bottomMarginBand1";
            // 
            // jOBFILETableAdapter
            // 
            this.jOBFILETableAdapter.ClearBeforeFill = true;
            // 
            // Quotation
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.ReportHeader,
            this.DetailReport1,
            this.DetailReport3,
            this.DetailReport5,
            this.DetailReport8,
            this.Selling_Prices,
            this.Del_Sched,
            this.Deliver_To,
            this.DetailReport9,
            this.DetailReport10,
            this.topMarginBand1,
            this.bottomMarginBand1});
            this.DataAdapter = this.jOBFILETableAdapter;
            this.DataMember = "JOBFILE";
            this.DataSource = this.dsQuotation;
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margins = new System.Drawing.Printing.Margins(43, 43, 22, 12);
            this.PageHeight = 1169;
            this.PageWidth = 827;
            this.PaperKind = System.Drawing.Printing.PaperKind.A4;
            this.ScriptReferencesString = "System.Data.DataSetExtensions.dll\r\nDevExpress.RichEdit.v11.1.dll\r\nDevExpress.Rich" +
    "Edit.v11.1.Core.dll\r\n";
            this.Scripts.OnBeforePrint = "Quotation_BeforePrint";
            this.ScriptsSource = resources.GetString("$this.ScriptsSource");
            this.Version = "11.1";
            ((System.ComponentModel.ISupportInitialize)(this.dsQuotation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrRTFAdditionalInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrlblTerms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.ReportHeaderBand ReportHeader;
        public Optima2.DataSets.Quotation dsQuotation;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport1;
        private DevExpress.XtraReports.UI.DetailBand AmendmentNumber;
        private DevExpress.XtraReports.UI.XRLabel xrlblAmendmentNumber;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport3;
        private DevExpress.XtraReports.UI.DetailBand Print_Job;
        private DevExpress.XtraReports.UI.XRLabel xrlblNoOfParts;
        private DevExpress.XtraReports.UI.XRLabel xrlblNoParts;
        private DevExpress.XtraReports.UI.XRLabel xrlblJobDescription;
        private DevExpress.XtraReports.UI.XRLabel xrLabel2;
        private DevExpress.XtraReports.UI.XRLabel xrlblOverallSize;
        private DevExpress.XtraReports.UI.XRLabel xrLabel3;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport5;
        private DevExpress.XtraReports.UI.DetailBand Additional_Info;
        private DevExpress.XtraReports.UI.XRLabel xrLabel8;
        private DevExpress.XtraReports.UI.XRRichText xrRTFAdditionalInformation;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport6;
        private DevExpress.XtraReports.UI.DetailBand Printjob_PrintSpec;
        private DevExpress.XtraReports.UI.XRLabel xrLabel4;
        private DevExpress.XtraReports.UI.XRLabel xrLabel9;
        private DevExpress.XtraReports.UI.XRLabel xrlblPrintSpecDesc;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport8;
        private DevExpress.XtraReports.UI.DetailBand RepeatInformation;
        private DevExpress.XtraReports.UI.XRLabel xrLabel10;
        private DevExpress.XtraReports.UI.XRLabel xrLabel11;
        private DevExpress.XtraReports.UI.DetailReportBand Selling_Prices;
        private DevExpress.XtraReports.UI.DetailBand Detail1;
        private DevExpress.XtraReports.UI.XRLabel xrLabel13;
        private DevExpress.XtraReports.UI.GroupHeaderBand GroupHeader2;
        private DevExpress.XtraReports.UI.DetailReportBand Del_Sched;
        private DevExpress.XtraReports.UI.DetailBand Detail3;
        private DevExpress.XtraReports.UI.XRLabel xrLabel17;
        private DevExpress.XtraReports.UI.XRLabel xrlblDelSchedInfo;
        private DevExpress.XtraReports.UI.DetailReportBand Deliver_To;
        private DevExpress.XtraReports.UI.DetailBand Detail4;
        private DevExpress.XtraReports.UI.XRLabel xrLabel18;
        private DevExpress.XtraReports.UI.XRLabel xrlblDeliveryTo;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport9;
        private DevExpress.XtraReports.UI.DetailBand Detail5;
        private DevExpress.XtraReports.UI.XRLabel xrlblDeliveryDate;
        private DevExpress.XtraReports.UI.XRLabel xrLabel19;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport10;
        private DevExpress.XtraReports.UI.DetailBand Terms;
        private DevExpress.XtraReports.UI.TopMarginBand topMarginBand1;
        private DevExpress.XtraReports.UI.BottomMarginBand bottomMarginBand1;
        private DevExpress.XtraReports.UI.XRTable xrTable1;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow1;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell1;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell2;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell3;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell4;
        private DevExpress.XtraReports.UI.XRLabel xrLabel6;
        private DevExpress.XtraReports.UI.XRLabel xrLabel15;
        private DevExpress.XtraReports.UI.GroupHeaderBand GroupHeader3;
        private DevExpress.XtraReports.UI.XRLabel xrLabel16;
        private DevExpress.XtraReports.UI.XRRichText xrlblTerms;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport;
        private DevExpress.XtraReports.UI.DetailBand Detail_PrintJob;
        private DataSets.QuotationTableAdapters.JOBFILETableAdapter jOBFILETableAdapter;
    }
}
