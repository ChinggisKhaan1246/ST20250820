using System;
using System.Collections.Generic;
using System.Text;
using Advantage.Data.Provider;
using System.IO;
using System.Windows.Forms;


using DevExpress.XtraRichEdit.API.Native;


namespace Optima2.Print
{
    public class Helper
    {

        public string substituteSlashcodes(string doc_type, string text, string salutation, string contact, string user_name,
                                            string user_tel, string user_fax, string user_email,
                                            string rep_name, string del_contact, string job_no,
                                            string job_inits, DateTime? req_by)
        {

            contact = contact == "" ? "Sir/Madam" : contact;
            salutation = salutation == "" ? contact : salutation;


            using (DevExpress.XtraRichEdit.RichEditControl rec = new DevExpress.XtraRichEdit.RichEditControl())
            {

              

                // date

                rec.Document.ReplaceAll("/d/", DateTime.Now.ToShortDateString(), DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (salutation != "")
                    rec.Document.ReplaceAll("/s/", salutation, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (contact != "")
                    rec.Document.ReplaceAll("/c/", contact, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (user_name != "")
                    rec.Document.ReplaceAll("/i/", user_name, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (user_tel != "")
                    rec.Document.ReplaceAll("/utel/", user_tel, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (user_fax != "")
                    rec.Document.ReplaceAll("/ufax/", user_fax, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (user_email != "")
                    rec.Document.ReplaceAll("/uemail/", user_email, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (req_by == null)
                    rec.Document.ReplaceAll("/ReqBy/", "  /  /    ", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                else
                    rec.Document.ReplaceAll("/ReqBy/", ((DateTime)req_by).ToShortDateString(), DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (rep_name != "")
                    rec.Document.ReplaceAll("/rep/", rep_name, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (del_contact != "")
                    rec.Document.ReplaceAll("/dc/", del_contact, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                if (job_no != "")
                {
                    string subst_job_no = "";
                    if (job_no.Length == 8)
                        subst_job_no = (job_inits == "" ? "" : job_inits) +
                           job_no.Substring(0, 2) + "/" +
                           job_no.Substring(2, 6) + "/";
                    else
                        subst_job_no = (job_inits == "" ? "" : job_inits) +
                       job_no.Substring(0, 2) + "/" +
                       job_no.Substring(2, 6) + "/" +
                       job_no.Substring(8, 2);

                    rec.Document.ReplaceAll("/job/", subst_job_no, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                }

                // NO PRINT (/X/)
                //if (doc_type != "Reps_Enquiry")
                //{
                //    if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.Text)
                //        rec.Text = ChopTextBetweenSlashCodes("/X/", rec, documentMode);
                //    else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.RichText)
                //        rec.RtfText = ChopTextBetweenSlashCodes("/X/", rec, documentMode);
                //    else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.HTML)
                //        rec.HtmlText = ChopTextBetweenSlashCodes("/X/", rec, documentMode); 
                //}                

                switch (doc_type)
                {
                    case "Enquiry":
                        {
                            //// for the order, we need to just remove the  NOCUST (/cust/), NOCUST2 (/C/),
                            //// because this is a supplier document.
                            //if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.Text)
                            //{
                            //    rec.Text = ChopTextBetweenSlashCodes("/cust/", rec, documentMode);
                            //    rec.Text = ChopTextBetweenSlashCodes("/C/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.Text = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}
                            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.RichText)
                            //{
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/cust/", rec, documentMode);
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/C/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}
                            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.HTML)
                            //{
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/cust/", rec, documentMode);
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/C/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}

                            // However, we do want to remove the '/supp/' and /S/ slash codes.
                            rec.Document.ReplaceAll("/supp/", "", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                            rec.Document.ReplaceAll("/S/", "", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                            break;

                        }

                    case "Quotation":
                        {
                            // for the quotation, we need to just remove the  NOSUPP (/supp/), NOSUPP2 (/S/),
                            // because this is a customer document.

                            //if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.Text)
                            //{
                            //    rec.Text = ChopTextBetweenSlashCodes("/supp/", rec, documentMode);
                            //    rec.Text = ChopTextBetweenSlashCodes("/S/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.Text = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}
                            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.RichText)
                            //{
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/supp/", rec, documentMode);
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/S/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}
                            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.HTML)
                            //{
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/supp/", rec, documentMode);
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/S/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}

                            // However, we do want to remove the '/cust/' and /C/ slash codes.
                            rec.Document.ReplaceAll("/cust/", "", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                            rec.Document.ReplaceAll("/C/", "", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                            break;
                        }
                    case "Acknowledgement":
                        {
                            // for the acknowledgement, we need to just remove the  NOSUPP (/supp/), NOSUPP2 (/S/),
                            // because this is a customer document.
                            //if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.Text)
                            //{
                            //    rec.Text = ChopTextBetweenSlashCodes("/supp/", rec, documentMode);
                            //    rec.Text = ChopTextBetweenSlashCodes("/S/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.Text = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}
                            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.RichText)
                            //{
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/supp/", rec, documentMode);
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/S/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}
                            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.HTML)
                            //{
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/supp/", rec, documentMode);
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/S/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);

                            //}

                            // However, we do want to remove the '/cust/' and /C/ slash codes.
                            rec.Document.ReplaceAll("/cust/", "", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                            rec.Document.ReplaceAll("/C/", "", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                            break;
                        }
                    case "Order":
                        {
                            // for the order, we need to just remove the  NOCUST (/cust/), NOCUST2 (/C/),
                            // because this is a supplier document.
                            //if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.Text)
                            //{
                            //    rec.Text = ChopTextBetweenSlashCodes("/cust/", rec, documentMode);
                            //    rec.Text = ChopTextBetweenSlashCodes("/C/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.Text = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}
                            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.RichText)
                            //{
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/cust/", rec, documentMode);
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/C/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.RtfText = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}
                            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.HTML)
                            //{
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/cust/", rec, documentMode);
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/C/", rec, documentMode);

                            //    // also remove the /I/ codes.
                            //    rec.HtmlText = ChopTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //}

                            // However, we do want to remove the '/supp/' and /S/ slash codes.
                            rec.Document.ReplaceAll("/supp/", "", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                            rec.Document.ReplaceAll("/S/", "", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                            break;
                        }

                    case "Invoice":
                        {
                            //if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.Text)
                            //    rec.Text = GetTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //else if(documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.RichText)
                            //    rec.RtfText = GetTextBetweenSlashCodes("/inv/", rec, documentMode);
                            //else if(documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.HTML)
                         //       rec.HtmlText = GetTextBetweenSlashCodes("/inv/", rec, documentMode);

                            // Remove the /inv/ code from the text.
                            rec.Document.ReplaceAll("/inv/", "", DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                            break;
                        }

                }

                //if(documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.Text)
                //    text = rec.Text;
                //else if(documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.RichText)
                //    text = rec.RtfText;
                //else if(documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.HTML)
                //    text = rec.HtmlText;

            }


            return text;
        }


        private string GetTextBetweenSlashCodes(string code, DevExpress.XtraRichEdit.RichEditControl rec)
        {
            int pos = 0;
            using (DevExpress.XtraRichEdit.RichEditControl newRec = new DevExpress.XtraRichEdit.RichEditControl())
            {

                DocumentRange[] occurences = rec.Document.FindAll(code, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

                while (occurences.GetLength(0) > 0)
                {

                    DocumentRange dr = occurences[0];
                    DocumentRange cutRange;

                    pos = dr.Start.ToInt();

                    try
                    {
                        Paragraph para = rec.Document.GetParagraph(dr.Start);

                        cutRange = rec.Document.CreateRange(pos, para.Range.End.ToInt() - pos);

                        // Insert text (not using clipboard)
                        newRec.Document.InsertDocumentContent(newRec.Document.CaretPosition, cutRange);

                        // now delete it.
                        rec.Document.Delete(cutRange);
                    }
                    catch
                    {
                    }

                    occurences = rec.Document.FindAll(code, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
                }

                string text = "";

                //if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.Text)
                //    text = newRec.Text;
                //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.RichText)
                //    text = newRec.RtfText;
                //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.HTML)
                //    text = newRec.HtmlText;

                return text;
            }
        }


        private string ChopTextBetweenSlashCodes(string code, DevExpress.XtraRichEdit.RichEditControl rec)
        {
            int pos = 0;

            DocumentRange[] occurences = rec.Document.FindAll(code, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);

            while (occurences.GetLength(0) > 0)
            {

                DocumentRange dr = occurences[0];
                DocumentRange cutRange;


                //    // find 2 pairs of /X/ and remove themselves and the text between them.
                // we don't do this anymore because it will always chop to the end of the paragraph/line.

                pos = dr.Start.ToInt();


                try
                {
                    Paragraph para = rec.Document.GetParagraph(dr.Start);

                    cutRange = rec.Document.CreateRange(pos, para.Range.End.ToInt() - pos);
                    rec.Document.Delete(cutRange);
                }
                catch
                {
                }

                occurences = rec.Document.FindAll(code, DevExpress.XtraRichEdit.API.Native.SearchOptions.CaseSensitive);
            }
            string text = "";

            //if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.Text)
            //    text = rec.Text;
            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.RichText)
            //    text = rec.RtfText;
            //else if (documentMode == Forms.RTFEditor.NotesEdit.DocumentMode.HTML)
            //    text = rec.HtmlText;


            return text;
        }

        //private string ChopTextBetweenSlashCodes(string code, string text)
        //{
        //    while (text.Contains(code))
        //    {
        //        // find 2 pairs of /X/ and remove themselves and the text between them.
        //        int pos = text.IndexOf(code);
        //        if (pos > -1)
        //        {
        //            int pos2 = text.IndexOf(code, pos + 1);
        //            if (pos2 > -1)
        //            {
        //                // we have something to chop up.
        //                string tempString = text.Substring(0, pos - 1);
        //                tempString = tempString + text.Substring(pos2 + code.Length);

        //                text = tempString;
        //            }
        //            else
        //            {
        //                // go the end of the paragraph e.g. /par
        //                pos2 = text.IndexOf(@"\par", pos + 1);
        //                if (pos2 > -1)
        //                {
        //                    // we have something to chop up.
        //                    string tempString = text.Substring(0, pos - 1);
        //                    tempString = tempString + text.Substring(pos2 + 4);

        //                    text = tempString;
        //                }
        //                else
        //                    break;
        //            }
        //        }
        //    }
        //    return text;
        //}

        //private string RemoveSlashCode(string code, string text)
        //{
        //    while (text.Contains(code))
        //    {
        //        text = text.Replace(code, "");
        //    }
        //    return text;
        //}

        #region "Printer Stuff"

        public enum PrintDestination
        {
            None = 0,
            Printer = 1,
            Email = 2,
            Fax = 3
        }

        /// <summary>
        ///  Get print destination
        /// </summary>
        /// <returns></returns>
        public PrintDestination GetPrintDestination(bool disableFax)
        {
            PrintDestination dest = PrintDestination.Printer;
            //using (Optima2.Print.PrintEmailFaxChoices choices = new PrintEmailFaxChoices("Select Destination", disableFax))
            //{
            //    System.Windows.Forms.DialogResult res = choices.ShowDialog(Program.wndMain);
            //    switch (res)
            //    {
            //        case System.Windows.Forms.DialogResult.OK:
            //            dest = PrintDestination.Printer;
            //            break;
            //        case System.Windows.Forms.DialogResult.Yes:
            //            dest = PrintDestination.Email;
            //            break;
            //        case System.Windows.Forms.DialogResult.No:
            //            dest = PrintDestination.Fax;
            //            break;
            //        default:
            //            dest = PrintDestination.None;
            //            break;
            //    }
            //}

            return dest;
        }

        /// <summary>
        /// Method to load a document layout onto a report.
        /// </summary>
        /// <param name="r"></param>
        /// <param name="documentCode"></param>
        /// <param name="type"></param>
        public void LoadLayout(DevExpress.XtraReports.UI.XtraReport r, string documentCode, string type)
        {
            string fieldName = "";
            switch (type)
            {
                case "PRINT_HEADER":
                    fieldName = "PRINT_HLAYOUT";
                    break;
                case "PRINT_BODY":
                    fieldName = "PRINT_BLAYOUT";
                    break;
                case "EMAIL_HEADER":
                    fieldName = "EMAIL_HLAYOUT";
                    break;
                case "EMAIL_BODY":
                    fieldName = "EMAIL_BLAYOUT";
                    break;

            }


            AdsConnection adsConn = new AdsConnection(Properties.Settings.Default.ads8Connection);
            AdsDataAdapter daDocConfig = new AdsDataAdapter();
            //Optima2.DataSets.DocConfig dsDocConfig = new Optima2.DataSets.DocConfig();
            //try
            //{
            //    adsConn.Open();
            //    // note, the blob files my get too big for this eventually and may cause some slowdown.
            //    daDocConfig = new AdsDataAdapter("select * from view_docconfig where code='" + documentCode + "'", adsConn);
            //    dsDocConfig.Clear();
            //    daDocConfig.Fill(dsDocConfig, "docconfig");
            //}
            //catch (AdsException ex)
            //{
            //    throw ex;
            //}
            //finally
            //{
            //    if (adsConn.State == System.Data.ConnectionState.Open)
            //    {
            //        adsConn.Close();
            //    }
            //}

            //if (dsDocConfig.DOCCONFIG.Rows.Count > 0)
            //{

            //    if (dsDocConfig.DOCCONFIG.Rows[0][fieldName].ToString() != "")
            //    {
            //        byte[] dBytes = (byte[])dsDocConfig.DOCCONFIG.Rows[0][fieldName];
            //        System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
            //        string s = enc.GetString(dBytes);
            //        using (StreamWriter sw = new StreamWriter(new MemoryStream()))
            //        {
            //            sw.Write(s);
            //            sw.Flush();
            //            r.LoadLayout(sw.BaseStream);
            //        }
            //    }
            //}

        }

        public bool SendReport(DevExpress.XtraReports.UI.XtraReport r, Optima2.Print.Helper.PrintDestination dest, string email_address, string fax_number, string subject, string contactName, string bodyText, decimal tcard_id)
        {
            bool success = true;

            //switch (dest)
            //{
            //    case PrintDestination.Printer:
            //        // if we are printing, bring up the printer dialog to choose the printer.
            //        System.Windows.Forms.DialogResult res = r.PrintDialog();
            //        if (!( res == System.Windows.Forms.DialogResult.OK))
            //        {
            //            success = false;
            //        }
            //        break;

            //    default:

            //        // this is active fax stuff.
            //        try
            //        {
            //            // 1) Get the location of where to put the fax message.
            //            string scanFolder = Optima2.Classes.CommonFieldValues.GetActiveFaxEmailScanFolderPath();

            //            Optima2.Print.ActiveFaxMessage msg = new ActiveFaxMessage();

            //            if (dest == PrintDestination.Email)
            //            {
            //                msg.FromName = Optima2.Classes.CommonFieldValues.GetUsersFullName();
            //                msg.FromEmail = Optima2.Classes.CommonFieldValues.GetUsersEmailAddress();
            //                msg.ToName = contactName;
            //                msg.ToEmail = email_address;

            //                // get the email text
            //                if (bodyText == "")
            //                {
            //                    using (Optima2.DataSets.QuotationTableAdapters.RTFNOTESTableAdapter rtfnotesTableAdapter1 = new Optima2.DataSets.QuotationTableAdapters.RTFNOTESTableAdapter())
            //                    {

            //                        if ((int)rtfnotesTableAdapter1.GetNotesCountByCode("$") > 0)
            //                        {
            //                            bodyText = rtfnotesTableAdapter1.GetNotesByCode("$").ToString();

            //                        }
            //                    }
            //                }

            //                msg.addBodyText(this.substituteSlashcodes("$", bodyText, "", "",
            //                    Optima2.Classes.CommonFieldValues.GetUsersFullName(),
            //                    Optima2.Classes.CommonFieldValues.GetUsersTelephoneNumber(),
            //                    Optima2.Classes.CommonFieldValues.GetUsersFaxNumber(),
            //                    Optima2.Classes.CommonFieldValues.GetUsersEmailAddress(),
            //                    "",
            //                    "",
            //                    "",
            //                    "", null));


            //                // add in attachments if there are any.
            //                if (tcard_id > 0)
            //                {
            //                    msg.AddAttachments(tcard_id);
            //                }

            //            }
            //            else
            //            {
            //                msg.FromName = Optima2.Classes.CommonFieldValues.GetUsersFullName();
            //                msg.FromFax = Optima2.Classes.CommonFieldValues.GetUsersFaxNumber();
            //                msg.ToName = contactName;
            //                msg.ToFax = fax_number;

            //            }

            //            msg.Subject = subject;

            //            // this sends the report so it can be converted into a pdf and attached to the email.

            //            msg.Send(r);
            //        }
            //        catch(Exception ex)
            //        {
            //            DevExpress.XtraEditors.XtraMessageBox.Show("Error: " + Environment.NewLine + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //            success = false;
            //        }
            //        break;
            //}


            return success;
        }

        #endregion
    }
}

