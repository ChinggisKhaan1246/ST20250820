﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;
using DevExpress.XtraRichEdit.API.Native;

namespace Optima2.Print
{
    public partial class Quotation : DevExpress.XtraReports.UI.XtraReport
    {

        public string job_no = "01000015";



        public Boolean printSpecTitlePrinted = false;
        public Boolean deliveryScheduleTitlePrinted = false;

        public bool terms = false;

        public bool abbreviated = false;
             

        public Quotation()
        {
            InitializeComponent();
 
        }
   


      
    }
}